<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="dark">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

        <title>{{ $title ?? config('app.name') }}&reg; | RESULTADOS REALES</title>

        <link rel="icon" href="{{asset('main-page/favicon.ico')}}" sizes="any">
        {{-- <link rel="icon" href="/favicon.svg" type="image/svg+xml"> --}}
        {{-- <link rel="apple-touch-icon" href="/apple-touch-icon.png"> --}}

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        @vite(['resources/css/app.css', 'resources/js/app.js'])
        @fluxAppearance
    </head>
    <body class="min-h-screen bg-white antialiased dark:bg-linear-to-b dark:from-neutral-950 dark:to-neutral-900">
        <div class="bg-background flex min-h-svh flex-col items-center justify-center gap-6 p-6 md:p-10">
            <div class="flex w-full max-w-sm flex-col gap-2">
                <a href="https://WWW.tecnocert.com.co" class="flex flex-col items-center gap-2 font-medium" wire:navigate>
                    <span class="flex h-13 w-13 mb-1 items-center justify-center rounded-md">
                        <x-app-logo-icon class="size-16 fill-current text-black dark:text-white" />
                        
                    </span>
                    <span class="sr-only">{{ config('app.name', '') }}</span>
                </a>
                <div class="flex flex-col gap-6">
                    {{ $slot }}
                </div>
            </div>
        </div>
        @fluxScripts
    </body>
</html>
